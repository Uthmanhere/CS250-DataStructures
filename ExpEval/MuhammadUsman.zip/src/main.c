#include <stdio.h>
#include <stdbool.h>

#include "Stack.h"

bool expression_check(char * exp)
{
	for (unsigned int counter = 0; exp[counter] != 0; ++counter)
	{
		if (
				exp[counter] == '[' ||
				exp[counter] == '{' ||
				exp[counter] == '('
				)
			push(exp[counter]);
		else if (
				exp[counter] == ']' ||
				exp[counter] == '}' ||
				exp[counter] == ')'
				)
			pop();

		if (is_empty())
			return true;
		else
			return false;
	}
}


int main()
{
	char * expr = (char *)malloc(50 * sizeof(char));

	scanf("%s", expr);
	puts("");
	if (expression_check(expr))
		printf("the expression is correct\n");
	else
		printf("The expression is NOT correct\n");

	return 0;
}

